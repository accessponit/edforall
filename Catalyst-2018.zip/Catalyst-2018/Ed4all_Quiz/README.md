quiz-app
========

Pulls questions in from a JSON file, generates HTML structures to populate with the questions, then provides controls for the user to select and submit different answers. When all the questions have been asked, it gives you a final score.
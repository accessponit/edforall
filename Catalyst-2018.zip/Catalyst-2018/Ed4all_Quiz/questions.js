var Questions = { "question" : [
  {
    "question"  : "Why do we have to pay taxes?",
     "choice1"  : "Because not paying is a crime",
     "choice2"  : "Because the government forces us to do ",
     "choice3"  : "Taxes is how the government funds development of public facilities",
     "choice4"  : "I don't know",
     "choice5"  : "I think is meaningless",                    
     "correct"  : 3
  },
  
  {
    "question"  : "How much income tax is collected as a percentage of?",
     "choice1"  : "annual net income",
     "choice2"  : "crop harvest",
     "choice3"  : "I have no idea",
     "choice4"  : "total money in bank accounts",
     "choice5"  : "total expenditure",                    
     "correct"  : 1
  },
  
  {
    "question"  : "What is Voldemort's final horcrux?",
     "choice1"  : "A mirror",
     "choice2"  : "A snake",
     "choice3"  : "A brooch",
     "choice4"  : "Harry Potter",
     "choice5"  : "A violin",                    
     "correct"  : 2
  },
  
  {
    "question"  : "Who takes over as headmaster of Hogwarts after Dumbledore's death?",
     "choice1"  : "Voldemort",
     "choice2"  : "Narcissa Black",
     "choice3"  : "Professor Trelawny",
     "choice4"  : "Delores Umbridge",
     "choice5"  : "Professor Snape",                    
     "correct"  : 5
  },
  
  {
    "question"  : "Who killed Deatheater Antonin Dolohov during the Battle of Hogwarts?",
     "choice1"  : "Professor Flitwick",
     "choice2"  : "Ron Weasley",
     "choice3"  : "Falling Debris",
     "choice4"  : "Hermione Granger",
     "choice5"  : "A Troll",                    
     "correct"  : 1
  }
]};
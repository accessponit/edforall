A Pen created at CodePen.io. You can find this one at https://codepen.io/zerratar/pen/boPYdp.

 I just started playing this awesome game and wanted to recreate the character creation part :)
A Pen created at CodePen.io. You can find this one at https://codepen.io/alexzaworski/pen/qZXZXd.

 Create and download your own version of the CodePen default avatar! Comes pre-populated with some of CodePen's commonly-used colors.

Don't know how to change your profile image? Click your avatar at the top right of the screen --> click settings --> check the profile tab.

If you're an rgb type of guy/gal, you can paste rgb values into the inputs on color pickers and it'll handle that fine. Same goes for hsl (I think?).
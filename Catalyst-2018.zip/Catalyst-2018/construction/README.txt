A Pen created at CodePen.io. You can find this one at https://codepen.io/willhalling/pen/pgVddz.

 A simple holding page using Flexbox to evenly space the elements. And JavaScript for the countdown.